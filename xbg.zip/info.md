Forward BLE data from April Brother/AB BLE Gateway V4 to Home Assistant

