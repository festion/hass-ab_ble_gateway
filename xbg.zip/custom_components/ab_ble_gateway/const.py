"""Constants for the April Brother BLE Gateway integration."""

DOMAIN = "ab_ble_gateway"
